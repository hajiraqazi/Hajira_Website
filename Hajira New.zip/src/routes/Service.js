function Service() {
  return (
    <>
      <h1>This is Service</h1>
    </>
  );
}

export default Service;
