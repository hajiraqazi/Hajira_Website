function Contact() {
  return (
    <>
      <h1>This is Contact</h1>
    </>
  );
}

export default Contact;
